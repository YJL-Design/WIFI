# OledMenu
Light menu for Arduino displayed on Oled screen

The idea is there, but it lacks a good design. If you are eager to make use of it, a proposal is to take some code from LCDMenu repo (Lightweight branch has a nice approach for getNumber menu)

# License

GPLv3
